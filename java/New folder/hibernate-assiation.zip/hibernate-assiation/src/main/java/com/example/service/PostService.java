package com.example.service;

import com.example.entity.Post;

public interface PostService {
    public void addPost(Post post);
}
