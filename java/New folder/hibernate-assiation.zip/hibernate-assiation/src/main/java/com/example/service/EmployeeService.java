package com.example.service;

import com.example.entity.Employee;

public interface EmployeeService {
    public void addEmp(Employee employee);
}
