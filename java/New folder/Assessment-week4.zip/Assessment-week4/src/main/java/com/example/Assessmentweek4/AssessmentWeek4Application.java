package com.example.Assessmentweek4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssessmentWeek4Application {

	public static void main(String[] args) {
		SpringApplication.run(AssessmentWeek4Application.class, args);
	}

}
