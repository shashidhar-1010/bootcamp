package com.example.Assessmentweek4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentWeek4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
