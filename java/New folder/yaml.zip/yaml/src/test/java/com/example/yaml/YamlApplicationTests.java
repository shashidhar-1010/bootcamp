package com.example.yaml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YamlApplicationTests {

	@Test
	void contextLoads() {
	}

}
