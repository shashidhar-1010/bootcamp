package com.example.Hibernateassociation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateAssociationApplicationTests {

	@Test
	void contextLoads() {
	}

}
