package com.example.CPS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
