package com.example.CPS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpsApplication.class, args);
	}

}
